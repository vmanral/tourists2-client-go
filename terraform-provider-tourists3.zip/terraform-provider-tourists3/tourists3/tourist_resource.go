package tourists3

import (
    "context"
    "strconv"
    //"fmt"
    "time"

    "github.com/vmanral/tourists2-client-go"
    "github.com/hashicorp/terraform-plugin-framework/resource"
    "github.com/hashicorp/terraform-plugin-framework/resource/schema"
    "github.com/hashicorp/terraform-plugin-framework/types"
    "github.com/hashicorp/terraform-plugin-log/tflog"
)

// Ensure the implementation satisfies the expected interfaces.
var (
    _ resource.Resource = &orderResource{}
    _ resource.ResourceWithConfigure = &orderResource{}
)

// NewTourist3Resource is a helper function to simplify the provider implementation.
func NewTourist3Resource() resource.Resource {
    return &orderResource{}
}

// orderResource is the resource implementation.
type orderResource struct {
    client *tourists3.Client
}

// orderResourceModel maps the resource schema data.
type orderResourceModel struct {
    Tourist    []orderTouristModel `tfsdk:"tourist"`
}

// orderTouristModel maps order item data.
type orderTouristModel struct {
  ID          types.String  `tfsdk:"id"`
  Name        types.String  `tfsdk:"name"`
  Email       types.String  `tfsdk:"email"`
  Gender      types.String  `tfsdk:"gender"`
  Status      types.String  `tfsdk:"status"`
  LastUpdated types.String  `tfsdk:"last_updated"`
}

// Metadata returns the resource type name.
func (r *orderResource) Metadata(_ context.Context, req resource.MetadataRequest, resp *resource.MetadataResponse) {
    resp.TypeName = req.ProviderTypeName + "_order"
}

// Schema defines the schema for the resource.
func (r *orderResource) Schema(_ context.Context, _ resource.SchemaRequest, resp *resource.SchemaResponse) {
    resp.Schema = schema.Schema{
        Attributes: map[string]schema.Attribute{
            "id": schema.StringAttribute{
                Computed: true,
            },
            "name": schema.StringAttribute{
                Required: true,
            },
            "email": schema.StringAttribute{
                Required: true,
            },
            "gender": schema.StringAttribute{
                Required: true,
            },
            "status": schema.StringAttribute{
                Required: true,
            },
            "last_updated": schema.StringAttribute{
                Description: "Timestamp of the last Terraform update of the order.",
                Computed:    true,
            },
        },
    }
}

// Create a new resource
func (r *orderResource) Create(ctx context.Context, req resource.CreateRequest, resp *resource.CreateResponse) {
    // Retrieve values from plan
    tflog.Info(ctx, "Adding new Tourist")
    //var plan orderResourceModel
    var plan orderTouristModel
    diags := req.Plan.Get(ctx, &plan)
    resp.Diagnostics.Append(diags...)
    if resp.Diagnostics.HasError() {
        return
    }

    // Generate API request body from plan
    var items tourists3.TouristInput
    //for _, item := range plan.Tourist {
    items = tourists3.TouristInput{
			//ID: int(item.ID.ValueInt64()),
			Name:     string(plan.Name.ValueString()),
			Email:    string(plan.Email.ValueString()),
			Gender:   string(plan.Gender.ValueString()),
			Status:   string(plan.Status.ValueString()),
		}
    //}

    // Create new order
    order, err := r.client.CreateNewTourist(items)
    ctx = tflog.SetField(ctx, "Order: ", order)
    //ctx = tflog.SetField(ctx, "Error: ", err.Error())
    tflog.Debug(ctx, "Added new Tourist")
    if err != nil {
        resp.Diagnostics.AddError(
            "Error creating tourist",
            "Could not create order, unexpected error: "+err.Error(),
        )
        return
    }

    //plan.ID = types.Int64Value(int64(order.ID))
    plan.ID = types.StringValue(strconv.Itoa(order.ID))
    plan.Name = types.StringValue(order.Name)
    plan.Email = types.StringValue(order.Email)
    plan.Gender = types.StringValue(order.Gender)
    plan.Status = types.StringValue(order.Status)
    plan.LastUpdated = types.StringValue(time.Now().Format(time.RFC850))

    // Set state to fully populated data
    diags = resp.State.Set(ctx, plan)
    resp.Diagnostics.Append(diags...)
    if resp.Diagnostics.HasError() {
        return
    }
}

// Read resource information
func (r *orderResource) Read(ctx context.Context, req resource.ReadRequest, resp *resource.ReadResponse) {
    tflog.Info(ctx, "Reading the Tourist")
    // Get current state
    var state orderTouristModel
    diags := req.State.Get(ctx, &state)
    resp.Diagnostics.Append(diags...)
    if resp.Diagnostics.HasError() {
        return
    }

    // Get refreshed order value from Tourists
    order, err := r.client.GetSpecificTourist(state.ID.ValueString())
    if err != nil {
        resp.Diagnostics.AddError(
            "Error Reading Tourist details",
            "Could not read Tourist details "+state.ID.ValueString()+": "+err.Error(),
        )
        return
    }

    // Overwrite items with refreshed state
    state.ID = types.StringValue(strconv.Itoa(order.ID))
    state.Name = types.StringValue(order.Name)
    state.Email = types.StringValue(order.Email)
    state.Gender = types.StringValue(order.Gender)
    state.Status = types.StringValue(order.Status)

    // Set refreshed state
    diags = resp.State.Set(ctx, &state)
    resp.Diagnostics.Append(diags...)
    if resp.Diagnostics.HasError() {
        return
    }
}

// Update updates the resource and sets the updated Terraform state on success.
func (r *orderResource) Update(ctx context.Context, req resource.UpdateRequest, resp *resource.UpdateResponse) {
    // Get current state
    var state orderTouristModel
    diags := req.State.Get(ctx, &state)
    resp.Diagnostics.Append(diags...)
    if resp.Diagnostics.HasError() {
        return
    }

    // Retrieve values from plan
    var plan orderTouristModel
    //var plan orderResourceModel
    diags2 := req.Plan.Get(ctx, &plan)
    resp.Diagnostics.Append(diags2...)
    if resp.Diagnostics.HasError() {
        return
    }

    // Generate API request body from plan
    var items tourists3.TouristInput
    items = tourists3.TouristInput{
			//ID: int(item.ID.ValueInt64()),
			Name:     string(plan.Name.ValueString()),
			Email:    string(plan.Email.ValueString()),
			Gender:   string(plan.Gender.ValueString()),
			Status:   string(plan.Status.ValueString()),
		}

    // Update existing order
    ctx = tflog.SetField(ctx, "Tourist Id: ", state.ID.ValueString())
    ctx = tflog.SetField(ctx, "Items: ", items)

    result, err := r.client.UpdateTourist(state.ID.ValueString(), items)
    ctx = tflog.SetField(ctx, "Updated Tourist Info: ", result)
    //ctx = tflog.SetField(ctx, "Error: ", err.Error())
    tflog.Debug(ctx, "Updated the Tourist")
    if err != nil {
        resp.Diagnostics.AddError(
            "Error Updating Tourist",
            "Could not update tourist, unexpected error: "+err.Error(),
        )
        return
    }

    // Fetch updated items from GetSpecificTourist as UpdateTourist items are not
    // populated.
    order, err := r.client.GetSpecificTourist(state.ID.ValueString())
    if err != nil {
        resp.Diagnostics.AddError(
            "Error Reading Tourist Id",
            "Could not read Tourist ID "+state.ID.ValueString()+": "+err.Error(),
        )
        return
    }

    // Update resource state with updated items and timestamp
    plan.ID = types.StringValue(strconv.Itoa(order.ID))
    plan.Name = types.StringValue(order.Name)
    plan.Email = types.StringValue(order.Email)
    plan.Gender = types.StringValue(order.Gender)
    plan.Status = types.StringValue(order.Status)
    plan.LastUpdated = types.StringValue(time.Now().Format(time.RFC850))


    diags = resp.State.Set(ctx, plan)
    resp.Diagnostics.Append(diags...)
    if resp.Diagnostics.HasError() {
        return
    }
;}

// Delete deletes the resource and removes the Terraform state on success.
func (r *orderResource) Delete(ctx context.Context, req resource.DeleteRequest, resp *resource.DeleteResponse) {
    // Retrieve values from state
    var state orderTouristModel
    diags := req.State.Get(ctx, &state)
    resp.Diagnostics.Append(diags...)
    if resp.Diagnostics.HasError() {
        return
    }

    // Delete existing order
    err := r.client.DeleteTourist(state.ID.ValueString())
    ctx = tflog.SetField(ctx, "Tourist Deleted: ", err.Error())
    //if err != nil {
    //    resp.Diagnostics.AddError(
    //        "Error Deleting Tourist",
    //        "Could not delete tourist, unexpected error: "+err.Error(),
    //    )
    //    return
    //}
}

// Configure adds the provider configured client to the resource.
func (r *orderResource) Configure(ctx context.Context, req resource.ConfigureRequest, _ *resource.ConfigureResponse) {
    tflog.Info(ctx, "Configuring Tourist")
    if req.ProviderData == nil {
        return
    }

    r.client = req.ProviderData.(*tourists3.Client)
}
