package tourists3

import (
    "context"

    "github.com/vmanral/tourists2-client-go"
    "github.com/hashicorp/terraform-plugin-framework/datasource"
    "github.com/hashicorp/terraform-plugin-framework/datasource/schema"
    "github.com/hashicorp/terraform-plugin-framework/types"
)

// Ensure the implementation satisfies the expected interfaces.
var (
    _ datasource.DataSource = &touristsDataSource{}
    _ datasource.DataSourceWithConfigure = &touristsDataSource{}
)

// NewTourists3DataSource is a helper function to simplify the provider implementation.
func NewTourists3DataSource() datasource.DataSource {
    return &touristsDataSource{}
}

// touristsDataSource is the data source implementation.
type touristsDataSource struct {
    client *tourists3.Client
}

// touristsDataSourceModelmaps the data source schema data.
type touristsDataSourceModel struct {
    Tourists []touristsModel `tfsdk:"tourists"`
}

// touristsModel maps coffees schema data.
type touristsModel struct {
    ID          types.Int64               `tfsdk:"id"`
    //ID          types.String              `tfsdk:"id"`
    Name        types.String              `tfsdk:"name"`
    Email       types.String              `tfsdk:"email"`
    Gender      types.String              `tfsdk:"gender"`
    Status      types.String              `tfsdk:"status"`
}

// Metadata returns the data source type name.
func (d *touristsDataSource) Metadata(_ context.Context, req datasource.MetadataRequest, resp *datasource.MetadataResponse) {
    resp.TypeName = req.ProviderTypeName + "_tourist"
}

// Schema defines the schema for the data source.
func (d *touristsDataSource) Schema(_ context.Context, _ datasource.SchemaRequest, resp *datasource.SchemaResponse) {
    resp.Schema = schema.Schema{
        Attributes: map[string]schema.Attribute{
            "tourists": schema.ListNestedAttribute{
                Computed: true,
                NestedObject: schema.NestedAttributeObject{
                    Attributes: map[string]schema.Attribute{
                        "id": schema.Int64Attribute{
                            Computed: true,
                        },
                        "name": schema.StringAttribute{
                            Computed: true,
                        },
                        "email": schema.StringAttribute{
                            Computed: true,
                        },
                        "gender": schema.StringAttribute{
                            Computed: true,
                        },
                        "status": schema.StringAttribute{
                            Computed: true,
                        },
                    },
                },
            },
        },
    }
}

// Read refreshes the Terraform state with the latest data.
func (d *touristsDataSource) Read(ctx context.Context, req datasource.ReadRequest, resp *datasource.ReadResponse) {
    var state touristsDataSourceModel

    tourists, err := d.client.GetTourists()
    if err != nil {
        resp.Diagnostics.AddError(
            "Unable to Read Tourists",
            err.Error(),
        )
        return
    }

    // Map response body to model
    for _, tourist := range tourists {
        touristState := touristsModel{
            ID:          types.Int64Value(int64(tourist.ID)),
            //ID:          types.StringValue(tourist.ID),
            Name:        types.StringValue(tourist.Name),
            Email:       types.StringValue(tourist.Email),
            Gender:      types.StringValue(tourist.Gender),
            Status:      types.StringValue(tourist.Status),
        }

        state.Tourists = append(state.Tourists, touristState)
    }

    // Set state
    diags := resp.State.Set(ctx, &state)
    resp.Diagnostics.Append(diags...)
    if resp.Diagnostics.HasError() {
        return
    }
}

// Configure adds the provider configured client to the data source.
func (d *touristsDataSource) Configure(_ context.Context, req datasource.ConfigureRequest, _ *datasource.ConfigureResponse) {
    if req.ProviderData == nil {
        return
    }

    d.client = req.ProviderData.(*tourists3.Client)
}
